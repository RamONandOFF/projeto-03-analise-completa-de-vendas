# 📊 Análise Completa de Vendas - Contoso Retail

## 🧠 Objetivo
Realizar uma análise completa das vendas da Contoso Retail utilizando apenas SQL no SQL Server, com foco em didática e clareza. Este projeto simula uma situação real onde a diretoria da empresa busca insights estratégicos para melhorar o desempenho comercial.

## 🏢 Contexto do Problema
Durante uma reunião trimestral, a diretoria da Contoso Retail identificou queda nas vendas em algumas regiões e a necessidade de entender melhor os produtos mais vendidos, categorias mais lucrativas e tendências por região.

Eles contrataram um analista de dados (nós!) para explorar o banco de dados `ContosoRetailDW` e responder às principais perguntas de negócio com base nas informações de vendas.

## 🔧 Ferramentas e Técnicas
- SQL Server
- SQL Server Management Studio (SSMS)
- Comandos SQL: `SELECT`, `JOIN`, `GROUP BY`, `ORDER BY`, `AVG`, `SUM`, `CTE`

## 📂 Tabelas Utilizadas
- `FactSales`: dados de vendas
- `DimProduct`: informações dos produtos
- `DimProductSubcategory` e `DimProductCategory`: hierarquia de produtos
- `DimDate`: datas das transações
- `DimGeography`: localização das vendas

---

## 🔍 Etapas da Análise

### 1️⃣ Consulta Exploratória: Quantidade de Registros
Queremos entender a quantidade de dados disponíveis.

📷 Resultado:
![Consulta 1](imagens/consulta1_total_registros.jpg)

---

### 2️⃣ Média de Vendas na Região Sul
A diretoria quer saber a média de vendas por transação apenas na região Sul.

📷 Resultado:
![Consulta 2](imagens/consulta2_media_sul.jpg)

---

### 3️⃣ Top 5 Produtos Mais Vendidos por Categoria
Produtos com maior volume de vendas agrupados por categoria.

📷 Resultado:
![Consulta 3](imagens/consulta3_top5_produtos_categoria.jpg)

---

### 4️⃣ Vendas por Mês (Tendência)
Entender como as vendas se comportaram mês a mês.

📷 Resultado:
![Consulta 4](imagens/consulta4_vendas_mensais.jpg)

---

### 5️⃣ Receita Total por Categoria e Subcategoria
Quais categorias e subcategorias geram mais receita.

📷 Resultado:
![Consulta 5](imagens/consulta5_receita_categoria.jpg)

---

## ✅ Conclusão

- A **Região Sul** tem desempenho médio inferior ao esperado; pode ser necessário investigar causas locais.
- Produtos da **categoria "Eletrônicos"** são os mais vendidos, com destaque para laptops.
- A tendência de vendas mostra **queda nos meses de inverno**, sugerindo uma sazonalidade que pode ser explorada.
- A maior parte da **receita** vem de poucas subcategorias, sugerindo foco em produtos de alto giro.

## 📁 Estrutura do Projeto
```
/contoso-projeto-completo-sql
│
├── README.md
├── imagens/
│   ├── consulta1_total_registros.jpg
│   ├── consulta2_media_sul.jpg
│   ├── ...
└── consulta.sql
```

---

Desenvolvido por Ramon Ribeiro – Projeto 100% SQL e didático para quem está começando. 🚀
