-- Análise Completa de Vendas - Contoso Retail
-- Desenvolvido por Ramon Ribeiro

-- Consulta 1: Quantidade total de registros na tabela de vendas
SELECT COUNT(*) AS Total_Registros
FROM FactSales;

-- Consulta 2: Média de vendas por transação na Região Sul
-- Unimos a tabela de vendas com localização e filtramos pela região "South"
SELECT 
     G.RegionCountryName
    ,AVG(F.SalesAmount) AS Media_Vendas_Sul
FROM FactSales AS F
JOIN DimGeography AS G ON F.SalesTerritoryKey = G.SalesTerritoryKey
WHERE G.RegionCountryName = 'South'
GROUP BY G.RegionCountryName;

-- Consulta 3: Top 5 produtos mais vendidos por categoria
-- Usamos CTE para facilitar a leitura e ranqueamento por quantidade vendida
WITH ProdutosMaisVendidos AS (
    SELECT 
         C.ProductCategoryName
        ,P.ProductName
        ,SUM(F.SalesQuantity) AS QuantidadeVendida
        ,RANK() OVER (PARTITION BY C.ProductCategoryName ORDER BY SUM(F.SalesQuantity) DESC) AS Posicao
    FROM FactSales AS F
    JOIN DimProduct AS P ON F.ProductKey = P.ProductKey
    JOIN DimProductSubcategory AS S ON P.ProductSubcategoryKey = S.ProductSubcategoryKey
    JOIN DimProductCategory AS C ON S.ProductCategoryKey = C.ProductCategoryKey
    GROUP BY C.ProductCategoryName, P.ProductName
)
SELECT *
FROM ProdutosMaisVendidos
WHERE Posicao <= 5;

-- Consulta 4: Tendência de vendas por mês
-- Agrupamos por ano e mês para identificar padrões sazonais
SELECT 
     D.CalendarYear
    ,D.EnglishMonthName
    ,SUM(F.SalesAmount) AS TotalVendas
FROM FactSales AS F
JOIN DimDate AS D ON F.DateKey = D.DateKey
GROUP BY D.CalendarYear, D.EnglishMonthName, D.MonthNumberOfYear
ORDER BY D.CalendarYear, D.MonthNumberOfYear;

-- Consulta 5: Receita por categoria e subcategoria
-- Agrupamos níveis de produto para entender a origem da receita
SELECT 
     C.ProductCategoryName
    ,S.ProductSubcategoryName
    ,SUM(F.SalesAmount) AS Receita_Total
FROM FactSales AS F
JOIN DimProduct AS P ON F.ProductKey = P.ProductKey
JOIN DimProductSubcategory AS S ON P.ProductSubcategoryKey = S.ProductSubcategoryKey
JOIN DimProductCategory AS C ON S.ProductCategoryKey = C.ProductCategoryKey
GROUP BY C.ProductCategoryName, S.ProductSubcategoryName
ORDER BY Receita_Total DESC;
